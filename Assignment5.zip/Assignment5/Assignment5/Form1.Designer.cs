﻿namespace Assignment5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBoxBagel = new System.Windows.Forms.ListBox();
            this.listBoxSize = new System.Windows.Forms.ListBox();
            this.labelBagel = new System.Windows.Forms.Label();
            this.labelSize = new System.Windows.Forms.Label();
            this.labelOrderDetails = new System.Windows.Forms.Label();
            this.buttonAddToCart = new System.Windows.Forms.Button();
            this.groupBoxDisplay = new System.Windows.Forms.GroupBox();
            this.numericUpDownQuantity = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.sizeLabel = new System.Windows.Forms.Label();
            this.textBoxBagel = new System.Windows.Forms.TextBox();
            this.textBoxSize = new System.Windows.Forms.TextBox();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.listBoxBagelDisplay = new System.Windows.Forms.ListBox();
            this.listBoxSizeDisplay = new System.Windows.Forms.ListBox();
            this.listBoxPrice = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelOverallPrice = new System.Windows.Forms.Label();
            this.labelTotalPrice = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.panelPrice = new System.Windows.Forms.Panel();
            this.buttonConfirm = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.listBoxQuantity = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonSummary = new System.Windows.Forms.Button();
            this.buttonStockReport = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBoxDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).BeginInit();
            this.panelPrice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listBoxBagel
            // 
            this.listBoxBagel.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxBagel.FormattingEnabled = true;
            this.listBoxBagel.ItemHeight = 15;
            this.listBoxBagel.Items.AddRange(new object[] {
            "HALLOUMI",
            "BANGKOK",
            "CHICKEN PHILLY",
            "CLASSIC CLUB",
            "KILTIMAGH SPECIAL",
            "VEGGIE",
            "PLOUGHMANS",
            "MEXICANA",
            "TRIPLE CHEESE",
            "ATLANTIC WAY",
            "BREAKFAST",
            "MAUI",
            "CLASSIC",
            "CHICKEN CAESER",
            "STUDENT SURPRISE",
            "CAJUN"});
            this.listBoxBagel.Location = new System.Drawing.Point(28, 100);
            this.listBoxBagel.Name = "listBoxBagel";
            this.listBoxBagel.Size = new System.Drawing.Size(139, 244);
            this.listBoxBagel.TabIndex = 0;
            this.toolTip1.SetToolTip(this.listBoxBagel, "Select a Bagel");
            this.listBoxBagel.SelectedIndexChanged += new System.EventHandler(this.listBoxBagel_SelectedIndexChanged);
            // 
            // listBoxSize
            // 
            this.listBoxSize.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxSize.FormattingEnabled = true;
            this.listBoxSize.ItemHeight = 15;
            this.listBoxSize.Items.AddRange(new object[] {
            "SMALL",
            "MEDIUM",
            "REGULAR",
            "LARGE",
            "EXTRA LARGE"});
            this.listBoxSize.Location = new System.Drawing.Point(192, 100);
            this.listBoxSize.Name = "listBoxSize";
            this.listBoxSize.Size = new System.Drawing.Size(123, 79);
            this.listBoxSize.TabIndex = 1;
            this.toolTip1.SetToolTip(this.listBoxSize, "Select a size");
            this.listBoxSize.SelectedIndexChanged += new System.EventHandler(this.listBoxSize_SelectedIndexChanged);
            // 
            // labelBagel
            // 
            this.labelBagel.AutoSize = true;
            this.labelBagel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBagel.Location = new System.Drawing.Point(24, 78);
            this.labelBagel.Name = "labelBagel";
            this.labelBagel.Size = new System.Drawing.Size(104, 19);
            this.labelBagel.TabIndex = 2;
            this.labelBagel.Text = "Select Bagel";
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSize.Location = new System.Drawing.Point(188, 78);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(87, 19);
            this.labelSize.TabIndex = 3;
            this.labelSize.Text = "Bagel Size";
            // 
            // labelOrderDetails
            // 
            this.labelOrderDetails.AutoSize = true;
            this.labelOrderDetails.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderDetails.Location = new System.Drawing.Point(94, 365);
            this.labelOrderDetails.Name = "labelOrderDetails";
            this.labelOrderDetails.Size = new System.Drawing.Size(54, 19);
            this.labelOrderDetails.TabIndex = 5;
            this.labelOrderDetails.Text = "Bagel";
            // 
            // buttonAddToCart
            // 
            this.buttonAddToCart.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonAddToCart.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddToCart.Location = new System.Drawing.Point(55, 179);
            this.buttonAddToCart.Name = "buttonAddToCart";
            this.buttonAddToCart.Size = new System.Drawing.Size(92, 24);
            this.buttonAddToCart.TabIndex = 6;
            this.buttonAddToCart.Text = "&Add to Order";
            this.toolTip1.SetToolTip(this.buttonAddToCart, "Add to Cart");
            this.buttonAddToCart.UseVisualStyleBackColor = false;
            this.buttonAddToCart.Click += new System.EventHandler(this.buttonAddToCart_Click);
            // 
            // groupBoxDisplay
            // 
            this.groupBoxDisplay.Controls.Add(this.numericUpDownQuantity);
            this.groupBoxDisplay.Controls.Add(this.label1);
            this.groupBoxDisplay.Controls.Add(this.sizeLabel);
            this.groupBoxDisplay.Controls.Add(this.textBoxBagel);
            this.groupBoxDisplay.Controls.Add(this.textBoxSize);
            this.groupBoxDisplay.Controls.Add(this.textBoxTotal);
            this.groupBoxDisplay.Controls.Add(this.buttonAddToCart);
            this.groupBoxDisplay.Controls.Add(this.labelTotal);
            this.groupBoxDisplay.Controls.Add(this.labelQuantity);
            this.groupBoxDisplay.Controls.Add(this.labelPrice);
            this.groupBoxDisplay.Controls.Add(this.textBoxPrice);
            this.groupBoxDisplay.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDisplay.Location = new System.Drawing.Point(339, 100);
            this.groupBoxDisplay.Name = "groupBoxDisplay";
            this.groupBoxDisplay.Size = new System.Drawing.Size(200, 219);
            this.groupBoxDisplay.TabIndex = 10;
            this.groupBoxDisplay.TabStop = false;
            this.groupBoxDisplay.Text = "Bagel Details";
            this.toolTip1.SetToolTip(this.groupBoxDisplay, "Bagel Details");
            // 
            // numericUpDownQuantity
            // 
            this.numericUpDownQuantity.Location = new System.Drawing.Point(80, 111);
            this.numericUpDownQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownQuantity.Name = "numericUpDownQuantity";
            this.numericUpDownQuantity.Size = new System.Drawing.Size(100, 22);
            this.numericUpDownQuantity.TabIndex = 11;
            this.numericUpDownQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownQuantity.ValueChanged += new System.EventHandler(this.numericUpDownQuantity_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Bagel";
            // 
            // sizeLabel
            // 
            this.sizeLabel.AutoSize = true;
            this.sizeLabel.Location = new System.Drawing.Point(27, 62);
            this.sizeLabel.Name = "sizeLabel";
            this.sizeLabel.Size = new System.Drawing.Size(26, 15);
            this.sizeLabel.TabIndex = 9;
            this.sizeLabel.Text = "Size";
            // 
            // textBoxBagel
            // 
            this.textBoxBagel.Location = new System.Drawing.Point(80, 33);
            this.textBoxBagel.Name = "textBoxBagel";
            this.textBoxBagel.ReadOnly = true;
            this.textBoxBagel.Size = new System.Drawing.Size(100, 22);
            this.textBoxBagel.TabIndex = 8;
            // 
            // textBoxSize
            // 
            this.textBoxSize.Location = new System.Drawing.Point(80, 59);
            this.textBoxSize.Name = "textBoxSize";
            this.textBoxSize.ReadOnly = true;
            this.textBoxSize.Size = new System.Drawing.Size(100, 22);
            this.textBoxSize.TabIndex = 7;
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.Location = new System.Drawing.Point(80, 137);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.ReadOnly = true;
            this.textBoxTotal.Size = new System.Drawing.Size(100, 22);
            this.textBoxTotal.TabIndex = 5;
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(8, 137);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(63, 15);
            this.labelTotal.TabIndex = 4;
            this.labelTotal.Text = "Total Price";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(15, 114);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(54, 15);
            this.labelQuantity.TabIndex = 2;
            this.labelQuantity.Text = "Quantity";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(27, 88);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(32, 15);
            this.labelPrice.TabIndex = 1;
            this.labelPrice.Text = "Price";
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(80, 85);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.ReadOnly = true;
            this.textBoxPrice.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrice.TabIndex = 0;
            // 
            // listBoxBagelDisplay
            // 
            this.listBoxBagelDisplay.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxBagelDisplay.FormattingEnabled = true;
            this.listBoxBagelDisplay.ItemHeight = 16;
            this.listBoxBagelDisplay.Location = new System.Drawing.Point(98, 387);
            this.listBoxBagelDisplay.Name = "listBoxBagelDisplay";
            this.listBoxBagelDisplay.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxBagelDisplay.Size = new System.Drawing.Size(121, 132);
            this.listBoxBagelDisplay.TabIndex = 11;
            this.toolTip1.SetToolTip(this.listBoxBagelDisplay, "Bagels Selected");
            // 
            // listBoxSizeDisplay
            // 
            this.listBoxSizeDisplay.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxSizeDisplay.FormattingEnabled = true;
            this.listBoxSizeDisplay.ItemHeight = 16;
            this.listBoxSizeDisplay.Location = new System.Drawing.Point(309, 387);
            this.listBoxSizeDisplay.Name = "listBoxSizeDisplay";
            this.listBoxSizeDisplay.Size = new System.Drawing.Size(108, 132);
            this.listBoxSizeDisplay.TabIndex = 12;
            this.toolTip1.SetToolTip(this.listBoxSizeDisplay, "Size");
            // 
            // listBoxPrice
            // 
            this.listBoxPrice.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxPrice.FormattingEnabled = true;
            this.listBoxPrice.ItemHeight = 16;
            this.listBoxPrice.Location = new System.Drawing.Point(423, 386);
            this.listBoxPrice.Name = "listBoxPrice";
            this.listBoxPrice.Size = new System.Drawing.Size(97, 132);
            this.listBoxPrice.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(305, 365);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 19);
            this.label2.TabIndex = 14;
            this.label2.Text = "Size";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(419, 364);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 15;
            this.label3.Text = "Price";
            // 
            // labelOverallPrice
            // 
            this.labelOverallPrice.AutoSize = true;
            this.labelOverallPrice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOverallPrice.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOverallPrice.Location = new System.Drawing.Point(91, 11);
            this.labelOverallPrice.Name = "labelOverallPrice";
            this.labelOverallPrice.Size = new System.Drawing.Size(0, 15);
            this.labelOverallPrice.TabIndex = 12;
            // 
            // labelTotalPrice
            // 
            this.labelTotalPrice.AutoSize = true;
            this.labelTotalPrice.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPrice.Location = new System.Drawing.Point(9, 14);
            this.labelTotalPrice.Name = "labelTotalPrice";
            this.labelTotalPrice.Size = new System.Drawing.Size(71, 15);
            this.labelTotalPrice.TabIndex = 16;
            this.labelTotalPrice.Text = "Total Price: ";
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.Tomato;
            this.buttonClear.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(134, 534);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(101, 42);
            this.buttonClear.TabIndex = 17;
            this.buttonClear.Text = "Cancel &Order";
            this.toolTip1.SetToolTip(this.buttonClear, "Click to cancel the order");
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // panelPrice
            // 
            this.panelPrice.BackColor = System.Drawing.Color.Peru;
            this.panelPrice.Controls.Add(this.labelTotalPrice);
            this.panelPrice.Controls.Add(this.labelOverallPrice);
            this.panelPrice.Location = new System.Drawing.Point(467, 534);
            this.panelPrice.Name = "panelPrice";
            this.panelPrice.Size = new System.Drawing.Size(134, 42);
            this.panelPrice.TabIndex = 18;
            // 
            // buttonConfirm
            // 
            this.buttonConfirm.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.buttonConfirm.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirm.Location = new System.Drawing.Point(28, 534);
            this.buttonConfirm.Name = "buttonConfirm";
            this.buttonConfirm.Size = new System.Drawing.Size(100, 42);
            this.buttonConfirm.TabIndex = 19;
            this.buttonConfirm.Text = "&Confirm";
            this.toolTip1.SetToolTip(this.buttonConfirm, "Click to confirm your order");
            this.buttonConfirm.UseVisualStyleBackColor = false;
            this.buttonConfirm.Click += new System.EventHandler(this.buttonConfirm_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(369, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Hobo Std", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(75, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(222, 27);
            this.label4.TabIndex = 21;
            this.label4.Text = "Welcome to Mr. Bagel\'s";
            // 
            // listBoxQuantity
            // 
            this.listBoxQuantity.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxQuantity.FormattingEnabled = true;
            this.listBoxQuantity.ItemHeight = 16;
            this.listBoxQuantity.Location = new System.Drawing.Point(225, 387);
            this.listBoxQuantity.Name = "listBoxQuantity";
            this.listBoxQuantity.Size = new System.Drawing.Size(78, 132);
            this.listBoxQuantity.TabIndex = 22;
            this.toolTip1.SetToolTip(this.listBoxQuantity, "Quantity");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(221, 365);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 19);
            this.label5.TabIndex = 23;
            this.label5.Text = "Quantity";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(526, 23);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(92, 27);
            this.buttonExit.TabIndex = 24;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonSummary
            // 
            this.buttonSummary.BackColor = System.Drawing.Color.Orange;
            this.buttonSummary.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSummary.Location = new System.Drawing.Point(241, 534);
            this.buttonSummary.Name = "buttonSummary";
            this.buttonSummary.Size = new System.Drawing.Size(102, 42);
            this.buttonSummary.TabIndex = 25;
            this.buttonSummary.Text = "&Summary";
            this.toolTip1.SetToolTip(this.buttonSummary, "Click for Smmary");
            this.buttonSummary.UseVisualStyleBackColor = false;
            this.buttonSummary.Click += new System.EventHandler(this.buttonSummary_Click);
            // 
            // buttonStockReport
            // 
            this.buttonStockReport.BackColor = System.Drawing.Color.Orange;
            this.buttonStockReport.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStockReport.Location = new System.Drawing.Point(353, 534);
            this.buttonStockReport.Name = "buttonStockReport";
            this.buttonStockReport.Size = new System.Drawing.Size(108, 42);
            this.buttonStockReport.TabIndex = 26;
            this.buttonStockReport.Text = "Stock &Report";
            this.toolTip1.SetToolTip(this.buttonStockReport, "Click for Stock Report");
            this.buttonStockReport.UseVisualStyleBackColor = false;
            this.buttonStockReport.Click += new System.EventHandler(this.buttonStockReport_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(630, 597);
            this.Controls.Add(this.buttonStockReport);
            this.Controls.Add(this.buttonSummary);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBoxQuantity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonConfirm);
            this.Controls.Add(this.panelPrice);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxPrice);
            this.Controls.Add(this.listBoxSizeDisplay);
            this.Controls.Add(this.listBoxBagelDisplay);
            this.Controls.Add(this.groupBoxDisplay);
            this.Controls.Add(this.labelOrderDetails);
            this.Controls.Add(this.labelSize);
            this.Controls.Add(this.labelBagel);
            this.Controls.Add(this.listBoxSize);
            this.Controls.Add(this.listBoxBagel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Mr. Bagel";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDisplay.ResumeLayout(false);
            this.groupBoxDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).EndInit();
            this.panelPrice.ResumeLayout(false);
            this.panelPrice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxBagel;
        private System.Windows.Forms.ListBox listBoxSize;
        private System.Windows.Forms.Label labelBagel;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.Label labelOrderDetails;
        private System.Windows.Forms.Button buttonAddToCart;
        private System.Windows.Forms.GroupBox groupBoxDisplay;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.TextBox textBoxTotal;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label sizeLabel;
        private System.Windows.Forms.TextBox textBoxBagel;
        private System.Windows.Forms.TextBox textBoxSize;
        private System.Windows.Forms.ListBox listBoxBagelDisplay;
        private System.Windows.Forms.ListBox listBoxSizeDisplay;
        private System.Windows.Forms.ListBox listBoxPrice;
        private System.Windows.Forms.NumericUpDown numericUpDownQuantity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelOverallPrice;
        private System.Windows.Forms.Label labelTotalPrice;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Panel panelPrice;
        private System.Windows.Forms.Button buttonConfirm;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBoxQuantity;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonSummary;
        private System.Windows.Forms.Button buttonStockReport;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

