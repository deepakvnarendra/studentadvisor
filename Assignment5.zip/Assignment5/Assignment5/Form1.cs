﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Assignment5
{
    public partial class Form1 : Form
    {
        //declaring global variables including arrays
        string bagels = "", size = "", confirmQuantity = "", confirmPrice = "";
        string bagelDisplay = "", sizeDisplay = "";
                        string quantityDisplay = "", priceDisplay = "", messageDisplay = "";
        string fetchBagel, fetchQuantity, fetchSize, fetchPrice;
        string[] bagelDetails = new string[100];
        string[] dailyTransactions = new string[100];

        //declaring filepaths
        const string finalPath = "C:/wamp64/", extension = ".txt";
        string bagelType,bagelStockFile = "C:/wamp64/stock.txt", bagelPriceFile = "C:/wamp64/price.txt", transactionFile = "C:/wamp/transactions.txt" ;
        string bagelName, sizeName;
        int quantity = 1, bagelIndex, sizeIndex, transaction = 0, count = 0, totalCount=0;
        const  int bagelRow = 16, bagelColumn=5;
        double totalPrice, overallPrice = 0.0, totalBagelsSold, totalSalesValue, totalTransactions, averageTransactions;

        // array of Bagels
        readonly static string[] bagelList = {"Halloumi", "Bangkok", "Chicken Philly", "Classic Club", "Kiltmagh Special", "Veggie",
            "Ploughmans", "Mexicana", "Triple Cheese", "Atlantic Way", "Breakfast", "Maui", "Classic", "Chicken Caeser",
            "Student Surprise", "Cajun"};
        // array of bagel sizes
        readonly string[] sizeList = {"Small", "Medium", "Regular", "Large", "Extra Large" };
        // 2D arrays for handling stock, prices and temperory array for performance within the program
        int[,] stockBagel = new int[bagelRow, bagelColumn];
        double[,] priceBagel = new double[bagelRow, bagelColumn];
        int[,] tempBagel = new int[bagelRow, bagelColumn];

        public Form1()
        {
            InitializeComponent();
        }

        //form load event handler
        private void Form1_Load(object sender, EventArgs e)
        {
            labelTotalPrice.Visible = false;
            labelOverallPrice.Visible = false;
            panelPrice.Visible = false;
           
            // method calls for price, stock files
                PriceFile();
                StockFile();
            // temperory array where stock details are inputted for use in program
                moveToTemp();
        }

        // bagel listbox index change event handler
        private void listBoxBagel_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            Display();
            
        }
        // size listbox index change event handler
        private void listBoxSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            Display();
            
        }

        // stock report event handler
        private void buttonStockReport_Click(object sender, EventArgs e)
        {
            // timestamp statement - to fetch the current time (helps the file to be unique)
            string currentTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
              string timeStamp = finalPath + currentTime + extension;

            // creating a new file using timestamp
            FileStream transactionFileWrite = File.Create(timeStamp);
            StreamWriter reportWriter = new StreamWriter(transactionFileWrite);
            
            // formatting the stock report
            string stockReport = "*******************************Mr.Bagel Kiltimagh *********************************"+
                "\n\n*****************************Stock Report * *****************************\n\n"+
                "\n\n***************************" + DateTime.Now.ToString("HH.mm: dd-MM-yyyy") + "* ***************************"+
                "\r\rnSize                               Type                                Quantity";
            
            reportWriter.WriteLine("**************************Mr.Bagel Kiltimagh * **************************");
            reportWriter.WriteLine("\n*****************************Stock Report * *****************************");
            reportWriter.WriteLine("\n*********************" + DateTime.Now.ToString("HH.mm: dd-MM-yyyy") + "*********************");
            reportWriter.WriteLine("\r\r\nSize                               Type                                Quantity");
            // displaying the details into the stock report
            for (int i = 0; i < bagelColumn; i++)
            {
                
                for (int j = 0; j < bagelRow; j ++)
                {
                    reportWriter.WriteLine(sizeList[i] + "\t\t\t\t" + bagelList[j] + "\t\t\t\t\t" + tempBagel[j,i] +"\n");

                }
            }

            MessageBox.Show("Please check for the text file  for stock details", "Information");
            reportWriter.Close();
        }

        // reading the stock file
        private void StockFile()
        {
            // exception handler if the file is not found
            try
            {
                // read all text and input them to a string
                string fileRead = File.ReadAllText(bagelStockFile);
                // ignore "Enter" cases in the file
                fileRead = fileRead.Replace("\r", "");

                int i = 0, j = 0;
                // navigate through every row until a newline is found
                foreach (var row in fileRead.Split('\n'))
                {
                    j = 0;
                    // navigate through every column of the row and split by , seperated values
                    foreach (var col in row.Trim().Split(','))
                    {
                        //input stock details from file into the stock array
                        stockBagel[i, j] = int.Parse(col.Trim());
                        j++;
                    }
                    i++;
                }
            }
            catch
            {
                MessageBox.Show("Bagel stock file not found!");
            }

        }
        //method to fetch bagel price details from the file
        private void PriceFile()
        {
            try
            {
                string fileRead1 = File.ReadAllText(bagelPriceFile);

                fileRead1.Replace("\r", "");
                int i = 0, j = 0;

                foreach (var row in fileRead1.Split('\n'))
                {
                    j = 0;
                    foreach (var col in row.Trim().Split(','))
                    {
                        priceBagel[i, j] = double.Parse(col.Trim());
                        j++;
                    }
                    i++;
                }
            }
            catch
            {
                MessageBox.Show("Bagel price file not found!");
            }
        }

        // summary button event handler
        private void buttonSummary_Click(object sender, EventArgs e)
        {
            if (totalTransactions != 0)
            {

                MessageBox.Show("Mr. Bagel Summary!! \n\n\n Total Bagels Sold: " + totalBagelsSold
                           + "\n\n Total Sales Value: " + totalSalesValue.ToString("c2")
                           + "\n\n Total number of Transactions: " + totalTransactions
                           + "\n\n Average value of a Transaction: " + averageTransactions.ToString("c2"), "Summary of the day");
            }
            else
            {
                MessageBox.Show("Atleast one transaction required to display summary!! ");
            }
        }

        // method to move the stock array to temp array
        // this array is used in the application for all processing
        // Later the updated array is moved to the stock file
        private void moveToTemp()
        {
            for (int k = 0; k < bagelRow; k++)
            {
                for (int l = 0; l < bagelColumn; l++)
                {
                    tempBagel[k, l] = stockBagel[k, l];
                }
            }
        }

        // Display method - Details of the transaction is displayed to the listbox
        private void Display()
        {
            //check if an item is selected in both bagel and size listboxes
            if (listBoxBagel.SelectedIndex != -1 && listBoxSize.SelectedIndex != -1)
            {
                //fetch the index of the listboxes and use them to fetch their value
                bagelIndex = listBoxBagel.SelectedIndex;
                sizeIndex = listBoxSize.SelectedIndex;

                bagelName = bagelList[bagelIndex];
                sizeName = sizeList[sizeIndex];

                bagelType = priceBagel[bagelIndex, sizeIndex].ToString();
                double bagelPrice = double.Parse(bagelType);
                textBoxPrice.Text = bagelPrice.ToString("c2");
                textBoxBagel.Text = bagelName;
                textBoxSize.Text = sizeName;
                //method call to calculate total price
                calculateTotal();
            }
           
        }

        // Add to cart event handler
        private void buttonAddToCart_Click(object sender, EventArgs e)
        {

            try
            {
                // checking if an item is selected in bagel and size listboxes
                if (listBoxBagel.SelectedIndex != -1 && listBoxSize.SelectedIndex != -1)
                {
                    if (numericUpDownQuantity.Value <= tempBagel[listBoxBagel.SelectedIndex, listBoxSize.SelectedIndex])
                    {
                        // method call for validating stock reduction from temp file when an order is added
                        stockCheck();
                        // add the bagel values to listboxes
                        listBoxBagelDisplay.Items.Add(bagelName);
                        listBoxQuantity.Items.Add(quantity);
                        listBoxSizeDisplay.Items.Add(sizeName);
                        listBoxPrice.Items.Add(totalPrice.ToString("c2"));
                        overallPrice += totalPrice;
                        labelOverallPrice.Text = overallPrice.ToString();

                        // clear necessary components once the order is added
                        labelTotalPrice.Visible = true;
                        listBoxBagel.ClearSelected();
                        listBoxSize.ClearSelected();
                        textBoxBagel.Clear();
                        textBoxSize.Clear();
                        textBoxPrice.Clear();
                        textBoxTotal.Clear();
                        numericUpDownQuantity.Value = 1;
                        textBoxTotal.Clear();
                        labelOverallPrice.Visible = true;
                        panelPrice.Visible = true;

                       
                    }
                    else 
                    {
                        // condition to check insufficient stock
                        if (tempBagel[listBoxBagel.SelectedIndex, listBoxSize.SelectedIndex] == 0)
                        {
                            MessageBox.Show("Insuffecient stock!");
                        }
                        else
                        {
                            //condition to show the number of available bagels
                            MessageBox.Show("There are only " + tempBagel[listBoxBagel.SelectedIndex, listBoxSize.SelectedIndex]+ 
                                " "+ bagelName+"s available. You can select a maximum of "+tempBagel[listBoxBagel.SelectedIndex,listBoxSize.SelectedIndex]
                                + " bagels");
                            numericUpDownQuantity.Value = tempBagel[listBoxBagel.SelectedIndex, listBoxSize.SelectedIndex];
                            
                        }
                    }

                }
                else
                {
                    // message if bagels and size isnt selected
                    MessageBox.Show("Please select a bagel and size!");
                }

            }
            catch
            {
                MessageBox.Show("Insufficient stock! Please select another bagel");
            }
        }

        //confirm button event handler
        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            // method for order confirmation
            confirmOrder();
            // resetting the overall price to 0
            overallPrice = 0;
  
            
        }

        // event handler for exit button
        private void buttonExit_Click(object sender, EventArgs e)
        {

            try
            {

                // writing to a file when exit button is pressed
                string currentTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                string timeStamp = finalPath + currentTime + extension;
                FileStream transactionFileWrite = File.Create(timeStamp);
                StreamWriter streamWriter = new StreamWriter(transactionFileWrite);


                for (int i = 0; i <= count; i++)
                {
                    streamWriter.WriteLine(bagelDetails[count]);

                }
                streamWriter.Close();
            }
            catch
            {
                MessageBox.Show("Exception if filepath not found");
            }
            this.Close();

        }

        // method to reduce the stock count from the temperory array
        private void stockCheck()
        {
                 int stockAvail = tempBagel[bagelIndex, sizeIndex];

                tempBagel[bagelIndex, sizeIndex] = stockAvail - quantity;
            
        }

        // method to calculate the total amount of the transaction
        private void calculateTotal()
        {
            if (listBoxBagel.SelectedIndex != -1 && listBoxSize.SelectedIndex != -1)
            {

                totalPrice = quantity * double.Parse(bagelType);
                textBoxTotal.Text = totalPrice.ToString("c2");

            }
        }

        // event handler for numericupdown component
        private void numericUpDownQuantity_ValueChanged(object sender, EventArgs e)
        {
            

                quantity = Convert.ToInt32(numericUpDownQuantity.Value);
                calculateTotal();
            
        }

        // event handler for cancel order
        private void buttonClear_Click(object sender, EventArgs e)
        {
            
            if (listBoxBagelDisplay.Items.Count != 0)
            {
                // update the temp array from the stock when an order is cancelled
                moveToTemp();

                itemsClear();
                numericUpDownQuantity.Value = 1;
              
                overallPrice = 0;
                labelOverallPrice.Text = "";

                panelPrice.Visible = false;
            }
            else
            {
                MessageBox.Show("There is no order to Cancel!");

            }
        }

        // method to clear components
        private void itemsClear()
        {
            listBoxBagel.ClearSelected();
            listBoxSize.ClearSelected();
            textBoxBagel.Clear();
            textBoxSize.Clear();
            textBoxPrice.Clear();
            textBoxTotal.Clear();
            listBoxBagelDisplay.Items.Clear();
            listBoxSizeDisplay.Items.Clear();
            listBoxPrice.Items.Clear();
            listBoxQuantity.Items.Clear();
            labelOverallPrice.Text = "";
            panelPrice.Visible = false;
        }

        // method for confirming the order and writing the updated stock into the file
        private void confirmOrder()
        {
            if (listBoxBagelDisplay.Items.Count != 0)
            {


                DialogResult res = MessageBox.Show("Do you want to confirm ?", "Confirmation !!", MessageBoxButtons.YesNo);

                if (res == DialogResult.Yes)
                {
                    // updating the total transactions
                    totalTransactions += 1;

                    try
                    {
                        // updating the stock file with new values
                        StreamWriter sWriter = new StreamWriter(bagelStockFile);

                        for (int i = 0; i < bagelRow; i++)
                        {
                            for (int j = 0; j < bagelColumn; j++)
                            {
                                // formatting the file
                                if ((i != 15) && (j == 4))
                                {
                                    sWriter.Write(tempBagel[i, j].ToString());
                                    sWriter.Write(Environment.NewLine);
                                }
                                else if ((i == 15) && (j == 4))
                                {

                                    sWriter.Write(tempBagel[i, j].ToString());
                                }
                                else
                                {
                                    sWriter.Write(tempBagel[i, j].ToString() + ",");
                                }

                            }

                        }

                        // fetching the bagel details from lisboxes to write to file
                        foreach (var item in listBoxBagelDisplay.Items)
                        {
                            bagels += item.ToString() + "                ";
                            totalBagelsSold += 1;
                        }
                        foreach (var item in listBoxSizeDisplay.Items)
                        {
                            size += item.ToString() + "                     ";
                        }
                        foreach (var item in listBoxQuantity.Items)
                        {
                            confirmQuantity += item.ToString() + "                                      ";
                        }
                        foreach (var item in listBoxPrice.Items)
                        {
                            confirmPrice += item.ToString() + "                              ";
                        }

                        messageDisplay = bagels + "\r" + size + "\r" + confirmQuantity + "\r"
                           + confirmPrice + "\r\r" + "Outstanding Amount: " + overallPrice.ToString("c2");


                        // displaying the message on confirmation
                        MessageBox.Show("Your order is Confirmed!\n\n Transaction Number: " + totalTransactions
                            + "\n\nDetails of your order are \n\n" + messageDisplay, "Confirmation");

                        // append transaction details to the file
                        StreamWriter sWrite = File.AppendText(transactionFile);

                        sWrite.WriteLine("\n\n");
                        sWrite.WriteLine("Transaction Number: " + totalTransactions);
                        sWrite.WriteLine("\nBagels ordered: " + bagels);

                        sWrite.WriteLine("\nPrices: " + confirmPrice);

                        sWrite.WriteLine("\n\nOverall Price: " + overallPrice);

                        bagels = ""; confirmQuantity = ""; confirmPrice = ""; size = "";

                        totalSalesValue += overallPrice;

                        averageTransactions = totalSalesValue / totalTransactions;
                        sWrite.Close();
                        sWriter.Close();

                        addToList();
                        itemsClear();
                    }
                    catch
                    {
                        //Exception handng for file not found and divide by zero
                        MessageBox.Show("Bagel File not found / Divide by 0 Exception");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an order!");
            }

        }
        // method to add items to array 
        private void addToList()
        {
            totalCount++;
            
            for(int m=0; m < listBoxBagelDisplay.Items.Count ; m++)
            {
               // count++;
                fetchBagel = listBoxBagelDisplay.Items[m].ToString();
                fetchQuantity = listBoxQuantity.Items[m].ToString();
                fetchSize = listBoxSizeDisplay.Items[m].ToString();
                fetchPrice = listBoxPrice.Items[m].ToString();

                bagelDetails[count] = fetchBagel + " " 
                    + fetchQuantity + " " + fetchSize + " " + fetchPrice + " " + overallPrice;
                
            }

        }
    }
    
}
