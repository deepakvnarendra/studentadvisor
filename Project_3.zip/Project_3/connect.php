<?php
$connection = mysqli_connect('localhost','root','');
if(!$connection)
{
	die("Database not connected - Failed".mysqli.error($connection));
}
$select_db = mysqli_select_db($connection,'studentadvisor');
if(!$select_db)
{
	die("Database not selected - Failed".mysqli.error($connection));
}
?>