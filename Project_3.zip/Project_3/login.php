<?php

session_start();
//include('connect.php');

$connection = mysqli_connect('localhost','root','');
if(!$connection)
{
	die("Database not connected - Failed".mysqli.error($connection));
}
$select_db = mysqli_select_db($connection,'studentadvisor');
//if(!$select_db)
//{
//	die("Database not selected - Failed".mysqli.error($connection));
//}

if(isset($_POST['username']) and isset($_POST['password']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$query = "SELECT * from login WHERE username = '".$username."' and password = '".$password."'";
	
	$result = mysqli_query($connection,$query) or die(mysqli_error($connection));
	$count = mysqli_num_rows($result);
	if($count == 1)
	{
		$_SESSION['username'] = $username;
	}
	else
	{
		header('Location:book_appointment.html');
		$message = "Invalid login credentials";
	}

}
if(isset($_SESSION['username']))
{
	$username = $_SESSION['username'];
	header('Location:main.html');
	//<script> window.location.href="main.php"</script>
	
	
	
}
?>