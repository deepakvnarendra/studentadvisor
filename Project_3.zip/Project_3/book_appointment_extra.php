<!DOCTYPE HTML>
<html lang="en-gb" class="no-js"> <!--<![endif]-->

<head>
	<title>Student Advisor</title>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="keywords" content="" />
	<meta name="description" content="" />
    
    <!-- Favicon --> 
	<link rel="shortcut icon" href="images/favicon.ico">
    
    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
   	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
    
    <!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
    
    <!-- ######### CSS STYLES ######### -->
	
    <link rel="stylesheet" href="css/reset.css" type="text/css" />
	<link rel="stylesheet" href="css/style.css" type="text/css" />
    
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    
    <!-- responsive devices styles -->
	<link rel="stylesheet" media="screen" href="css/responsive-leyouts.css" type="text/css" />
    
    <!-- animations -->
    <link href="js/animations/css/animations.min.css" rel="stylesheet" type="text/css" media="all" />
    
    <!-- mega menu -->
    <link href="js/mainmenu/sticky.css" rel="stylesheet">
    <link href="js/mainmenu/bootstrap.min.css" rel="stylesheet">
    <link href="js/mainmenu/demo.css" rel="stylesheet">
    <link href="js/mainmenu/menu.css" rel="stylesheet">
    
    <!-- slide panel -->
    <link rel="stylesheet" type="text/css" href="js/slidepanel/slidepanel.css">
    
	<!-- Master Slider -->
    <link rel="stylesheet" href="js/masterslider/style/masterslider.css" />
    <link rel="stylesheet" href="js/masterslider/skins/default/style.css" />
    <link rel="stylesheet" href="js/masterslider/style.css" />

	<!-- cubeportfolio -->
	<link rel="stylesheet" type="text/css" href="js/cubeportfolio/cubeportfolio.min.css">
    
	<!-- tabs -->
    <link rel="stylesheet" type="text/css" href="js/tabs/assets/css/responsive-tabs.css">
    <link rel="stylesheet" type="text/css" href="js/tabs/assets/css/responsive-tabs2.css">

	<!-- carousel -->
    <link rel="stylesheet" href="js/carousel/flexslider.css" type="text/css" media="screen" />
 	<link rel="stylesheet" type="text/css" href="js/carousel/skin.css" />
    
    <!-- accordion -->
    <link rel="stylesheet" href="js/accordion/accordion.css" type="text/css" media="all">
    
    <!-- Lightbox -->
    <link rel="stylesheet" type="text/css" href="js/lightbox/jquery.fancybox.css" media="screen" />
	
 
</head>
<style>
	

</style>
	
<body>


<div class="wrapper_boxed">

<div class="site_wrapper">

<div id="sliderWrap">

<div class="clearfix"></div>

<header id="header">

	<!-- Top header bar -->
	<div id="topHeader">
    
	<div class="wrapper">
         
        <div class="top_nav">
        <div class="container">
                
        <div class="right">
            
            <ul>
            	
                <li><a href="#"><i class="fa fa-envelope"></i> Email</a></li>
                <li><i class="fa fa-phone"></i> +00 000 000 0000</li>
            </ul>
            
        </div><!-- end right social links -->
        
        </div>
        </div>
            
 	</div>
    
	</div><!-- end top navigation -->
	
    
	<div id="trueHeader">
    
	<div class="wrapper">
    
     <div class="container">
    
		<!-- Logo -->
		<div class="logo"><a href="index.html" id="logo"></a></div>
		
	<!-- Menu -->
	<div class="menu_main">
        
	<div class="navbar yamm navbar-default">
    
    <div class="container">
      <div class="navbar-header">
        <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span>Menu</span>
          <button type="button" > <i class="fa fa-bars"></i></button>
        </div>
      </div>
      
      <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
      
        <ul class="nav navbar-nav">
        
        <li><a href="#"><i class="fa fa-home"></i> About</a></li>
        
        <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-leaf"></i> Academic</a>
            <ul class="dropdown-menu" role="menu">
            <li><a href="#">Sub Menu 1</a> </li>
            <li><a href="#">Sub Menu 2</a> </li>
            <li><a href="#">Sub Menu 3</a> </li>
            </ul>
        </li>
			
        <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-leaf"></i> Finance</a>
            <ul class="dropdown-menu" role="menu">
            <li><a href="#">Sub Menu 1</a> </li>
            <li><a href="#">Sub Menu 2</a> </li>
            <li><a href="#">Sub Menu 3</a> </li>
            </ul>
        </li>
			
			 <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-leaf"></i> Services</a>
            <ul class="dropdown-menu" role="menu">
            <li><a href="#">Sub Menu 1</a> </li>
            <li><a href="#">Sub Menu 2</a> </li>
            <li><a href="#">Sub Menu 3</a> </li>
            </ul>
        </li>
			
			 <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-leaf"></i> Contact</a>
            <ul class="dropdown-menu" role="menu">
            <li><a href="#">Sub Menu 1</a> </li>
            <li><a href="#">Sub Menu 2</a> </li>
            <li><a href="#">Sub Menu 3</a> </li>
            </ul>
        </li>
			
			<li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-leaf"></i> Home</a>
            <ul class="dropdown-menu" role="menu">
            <li><a href="#">Sub Menu 1</a> </li>
            <li><a href="#">Sub Menu 2</a> </li>
            <li><a href="#">Sub Menu 3</a> </li>
            </ul>
        </li>
    
			 <ul class="dropdown-menu" role="menu">
			
             
                    <li><a href="#"><i class="fa fa-angle-right"></i> Sub Menu 1</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Sub Menu 2</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Sub Menu 3</a></li>
                  
				</ul>
            
      </div>
      </div>
     </div>
     
	</div><!-- end menu -->
        
	</div>
		
	</div>
    
	</div>
    
</header>


<div class="fresh_works1">
<div class="container_full">
	<div class="cbp-l-loadMore-text">
	  <div data-href="#" class="cbp-l-loadMore-text-link"></div>
    	</div>

</div>
</div><!-- end fresh works1 -->




<div class="feature_section3"></div><!-- end features section3 -->

<br/>
<br/>


<!--<h2 align="center">Student Services 1</h2> -->
<div class="feature_section9">
 
<div id="mycenter">
 
  <table style="border: 1px solid black;width: 100%;background-color: skyblue;box-shadow: 0 0 50px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);">
  <tr>
    <td style="border: 1px solid black; text-align: center;font-size: 15px;padding-top: 15px;padding-bottom: 10px;padding-left: 10px;padding-top: 10px"><strong>Meet the Student Advisor</strong></td>
    <tr/>
	 </table>
	<hr/>

    
	<a href="book_appointment.html"><div class="jobs"> 
              </br> </br><h4 style = "color:#fff!important">Book an Appointment </h4>
    </div> </a>
	
	<div class="jobs"> 
              </br> </br><h4 style = "color:#fff!important">Email the Student Advisor </h4>
    </div>
	
  </div> 
  <div id='myright'>
	

<div class="container_appo">  
  <form id="contact" action="login.php" method="POST" >
    <h3>Login</h3>
    
    <fieldset>
      <input id= "username" placeholder="Username" type="text" tabindex="1" required autofocus>
    </fieldset>
	<fieldset>
      <input id = "password" placeholder="Password" type="text" tabindex="1" required autofocus >
    </fieldset>
	<!--<fieldset>
      <input placeholder="Course" type="text" tabindex="1" required autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address" type="email" tabindex="2" required>
    </fieldset>
    <fieldset>
      <input placeholder="Your Phone Number (optional)" type="tel" tabindex="3" required>
    </fieldset>	
      <textarea placeholder="Description" tabindex="5" required></textarea>
    </fieldset> -->
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" >Submit</button>
  </form>
</div>

  </div>
<!-- end features section 9 -->

<div class="footer1">
<div class="container">
<!-- end twitter feeds -->
	
	<div align="center">
    
    <div class="one_half last animate" data-anim-type="fadeInRight"> </div><!-- end newsletter sign up -->
    
    <div class="clearfix divider_dashed1"></div>
    
    <div class="one_fourth animate" data-anim-type="fadeInUp">
        <ul class="faddress">
            
			
            <li><h4>ABOUT NUI GALWAY</h4>	
            Founded in 1845, we've been inspiring <br>students for 170 years. NUI Galway has <br>earned international recognition as a <br>research-led university with a <br>commitment to top quality teaching.</li>
           
        </ul>
	</div><!-- end address -->
    
    <div class="one_fourth animate" data-anim-type="fadeInUp">
    <div class="qlinks">
    
    	<h4 class="lmb">CONTACTS</h4>
        
        <ul>
             <li><i class="fa fa-map-marker fa-lg"></i>&nbsp;National University of Ireland<br>Galway<br>University Road,<br>Galway, Ireland <br>H91TK33 <br>T: +353 91524411</li>
		</ul>
        
    </div>
	</div><!-- end links -->
        
    <div class="one_fourth animate" data-anim-type="fadeInUp">
    
    </div><!-- end site info -->
    
    <div class="one_fourth last animate" data-anim-type="fadeInUp">
        
        <h4>CONNECT</h4>
        
		<p class="twitter_feed" href = "twitter.com/nuigalway"> </p>
		<a href="http://www.nuigalway.ie/about-us/contact-us/where-to-find-us.html"><img src="images/footer_map.png" alt="Galway Mini Map"></a>
    </div><!-- end flickr -->
    
    
</div>
	</div>
</div><!-- end footer -->
<div class="copyright_info">
<div class="container">


    
    <div class="one_half animate" data-anim-type="fadeInRight">
    
		© 2017 National University of Ireland, Galway. All Rights Reserved.  <a href="#"> </a>
        
    </div>
	
	

<div class="copyright_info">
<div class="container">

    
    <div class="one_half animate" data-anim-type="fadeInRight">
    
		 <a href="#"> </a>
        
    </div>
    
    
    
</div><!-- end copyright info -->
</div>
</div>

    
<!-- ######### JS FILES ######### -->
<!-- get jQuery from the google apis -->
<script type="text/javascript" src="js/universal/jquery.js"></script>

<!-- style switcher -->
<script src="js/style-switcher/jquery-1.js"></script>
<script src="js/style-switcher/styleselector.js"></script>

<!-- animations -->
<script src="js/animations/js/animations.min.js" type="text/javascript"></script>


<!-- slide panel -->
<script type="text/javascript" src="js/slidepanel/slidepanel.js"></script>

<!-- Master Slider -->
<script src="js/masterslider/jquery.easing.min.js"></script>
<script src="js/masterslider/masterslider.min.js"></script>
<script type="text/javascript">
(function($) {
 "use strict";

var slider = new MasterSlider();
 slider.setup('masterslider' , {
     width: 1400,    // slider standard width
     height:580,   // slider standard height
     space:0,
	 speed:45,
     fullwidth:true,
     loop:true,
     preload:0,
     autoplay:true,
	 view:"basic"
});
// adds Arrows navigation control to the slider.
slider.control('arrows');
slider.control('bullets');

})(jQuery);
</script>

<!-- mega menu -->
<script src="js/mainmenu/bootstrap.min.js"></script> 
<script src="js/mainmenu/customeUI.js"></script> 

<!-- jquery jcarousel -->
<script type="text/javascript" src="js/carousel/jquery.jcarousel.min.js"></script>

<!-- scroll up -->
<script src="js/scrolltotop/totop.js" type="text/javascript"></script>

<!-- tabs -->
<script src="js/tabs/assets/js/responsive-tabs.min.js" type="text/javascript"></script>

<!-- jquery jcarousel -->
<script type="text/javascript">
(function($) {
 "use strict";

	jQuery(document).ready(function() {
			jQuery('#mycarouselthree').jcarousel();
	});
	
})(jQuery);
</script>


<!-- accordion -->
<script type="text/javascript" src="js/accordion/custom.js"></script>

<!-- sticky menu -->
<script type="text/javascript" src="js/mainmenu/sticky.js"></script>
<script type="text/javascript" src="js/mainmenu/modernizr.custom.75180.js"></script>

<!-- cubeportfolio -->
<script type="text/javascript" src="js/cubeportfolio/jquery.cubeportfolio.min.js"></script>
<script type="text/javascript" src="js/cubeportfolio/main.js"></script>
<script type="text/javascript" src="js/cubeportfolio/main5.js"></script>
<script type="text/javascript" src="js/cubeportfolio/main6.js"></script>

<!-- carousel -->
<script defer src="js/carousel/jquery.flexslider.js"></script>
<script defer src="js/carousel/custom.js"></script>

<!-- lightbox -->
<script type="text/javascript" src="js/lightbox/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/lightbox/custom.js"></script>



</body>
</html>
